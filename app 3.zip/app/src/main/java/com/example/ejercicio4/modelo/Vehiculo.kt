package com.example.ejercicio4.modelo

class Vehiculo(val tipo:String, val modelo: String, val precio:Double) {


}